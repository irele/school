package org;
import org.netsimulator.net.AddressException;
import org.netsimulator.net.IP4Address;

public class test2
{
    public static void main(String argv[])
    {
        IP4Address address = null;

        try
        {
            address = new IP4Address(argv[0]);
        }catch(AddressException ae)
        {
            ae.printStackTrace();
            System.exit(1);
        }

        System.out.println("address : "+address);
        System.out.println("address digit : "+Integer.toBinaryString(address.toIntValue()));
        System.out.println("netmask length : "+Integer.bitCount(address.toIntValue()));
        System.out.println("netmask length digit : "+Integer.toBinaryString(Integer.bitCount(address.toIntValue())));
//        System.out.println("netmask length : "+countNetmaskLength(address));
    }
    
    
    
    public static int countNetmaskLength(IP4Address netmask)
    {
        int count = 0;
        int addr = netmask.toIntValue();
        
        for(count=0; count!=32; count++)
        {
            System.out.println("buf digit : "+Integer.toBinaryString(addr));

            if( (addr | 0) == 0 )
            {
                break;
            }else
            {
                addr <<= 1;
            }
        }
            
        return count;
    }
}
