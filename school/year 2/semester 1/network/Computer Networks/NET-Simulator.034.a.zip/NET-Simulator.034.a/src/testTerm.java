package org;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import org.netsimulator.term.TerminalFrame;

public class testTerm extends JFrame
{

    public static void main(String argv[])
    {
        new TerminalFrame();
    }
}
