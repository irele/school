package org;
import org.netsimulator.net.AddressException;
import org.netsimulator.net.MACAddress;

public class test
{
    public static void main(String argv[])
    {
        MACAddress address = null;

        try
        {
            address = new MACAddress(argv[0]);
        }catch(AddressException ae)
        {
            ae.printStackTrace();
            System.exit(1);
        }

        System.out.println("long   : "+address.toLongValue());
        System.out.println("6 byte : "+address);
    }
}
