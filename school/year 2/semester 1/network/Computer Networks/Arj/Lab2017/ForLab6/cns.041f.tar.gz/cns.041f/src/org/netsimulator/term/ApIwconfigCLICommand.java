/*
Computer Network Simulator (CNS)
Copyright (C) 2006 Maxim Tereshin <maxim-tereshin@yandex.ru>
Copyright (C) 2012 Igor A. Nebaev <opds@darkstar.su>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
            
This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
General Public License for more details.
            
You should have received a copy of the GNU General Public License along 
with this program; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA 
*/

package org.netsimulator.term;


import java.io.Writer;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.logging.Logger;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.MissingArgumentException;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.UnrecognizedOptionException;
import org.netsimulator.net.AP;
import org.netsimulator.net.WifiNetworks;

public class ApIwconfigCLICommand implements CLICommand {
  private Terminal term;
  private Writer writer;
  private AP ap;
  private WifiNetworks wifi;
  private static final Options options = new Options();

  private static final Logger logger =
          Logger.getLogger("org.netsimulator.term.ApIwconfigCLICommand");

  private static final String ENABLE_OPTION = "enable";
  private static final String DISABLE_OPTION = "disable";
  private static final String PASSWORD_OPTION = "p";
  private static final String SSID_OPTION = "essid";
  private static final String HELP_OPTION = "h";

  /**
   * Constructor for wi-fi router (AP).
   * @param term console
   * @param ap Acess Point
   */
  public ApIwconfigCLICommand(Terminal term, AP ap) {
    this.term = term;
    this.ap = ap;

    wifi = WifiNetworks.getInstance();

    Option help = new Option(HELP_OPTION, false, "вывести справку");
    options.addOption(help);
    Option statusUp = new Option(ENABLE_OPTION, false,
            "активировать Wi-Fi интерфейс");
    Option statusDown = new Option(DISABLE_OPTION, false,
            "отключить Wi-Fi интерфейс");

      /* OptionGroup saved the state of selected option from parsing to parsing.
         There is not a way to clean the state. */
//        OptionGroup status = new OptionGroup();
//        status.addOption(statusUp);
//        status.addOption(statusDown);
//        options.addOptionGroup(status);

    options.addOption(statusUp);
    options.addOption(statusDown);
        
    Option password = OptionBuilder.withArgName("password")
            .hasArg()
            .withDescription("пароль для подключения к Wi-Fi сети")
            .create(PASSWORD_OPTION);
    options.addOption(password);

    Option ssid = OptionBuilder.withArgName("ESSID")
            .hasArg()
            .withDescription("ID Wi-Fi сети")
            .create(SSID_OPTION);
    options.addOption(ssid);
  }

  @Override
  public String getName() {
    return "iwconfig";
  }
  
  @Override
  public int Go(String argv[], String cl) throws IOException {
    CommandLineParser parser = new GnuParser();
    CommandLine cmd = null;
    try {
      cmd = parser.parse(options, argv);
    } catch (MissingArgumentException e) {
      writer.write("Недостаточно аргументов\n");
      return -1;
    } catch(UnrecognizedOptionException e) {
      writer.write("Недопустимые аргументы\n");
      return -1;
    } catch(ParseException e) {
      e.printStackTrace();
      return -1;
    }
 
    if(cmd.hasOption(HELP_OPTION)) {
      showHelp();
      return 0;
    }

    String args[] = cmd.getArgs();
    
    // unknown arguments
    if(args.length > 0
            && !cmd.hasOption(ENABLE_OPTION)
            && !cmd.hasOption(DISABLE_OPTION)
            && !cmd.hasOption(SSID_OPTION)
            && !cmd.hasOption(PASSWORD_OPTION)) {
      showHelp();
      return 0;
    }

    // if no arguments  show current status
    if(!cmd.hasOption(ENABLE_OPTION)
            && !cmd.hasOption(DISABLE_OPTION)
            && !cmd.hasOption(SSID_OPTION)
            && !cmd.hasOption(PASSWORD_OPTION)) {
      showStatus();
      return 0;
    }

       /* for(int i=0; i!=args.length; i++)
        {    
            System.err.println("args["+i+"]="+args[i]);
        }
        */

    String essid = null;
    String password = "";

    if(!cmd.hasOption(SSID_OPTION)) {
      writer.write("Не указан ESSID\n");
      return -1;
    }

    essid = cmd.getOptionValue(SSID_OPTION);
    if (essid.trim().length() < 3) {
      writer.write("Недопустимый ESSID\n");
      return -1;
    }

    if(cmd.hasOption(PASSWORD_OPTION)) {
      // If you change password, all current Wi-Fi connections will be
      // destroyed!
      password = cmd.getOptionValue(PASSWORD_OPTION);
      if (password.trim().length() < 3) {
        writer.write("Недопустимый пароль\n");
        return -1;
      }
    }

    if(cmd.hasOption(ENABLE_OPTION) && cmd.hasOption(DISABLE_OPTION)) {
      writer.write("Опции '-enable' и '-disable' взаимоисключаемы\n");
      return -1;
    }

    // try to execute command

    // if there are 'enable', 'essid' and 'p' (optionally) arugments create
    // Wi-Fi network
    if (cmd.hasOption(ENABLE_OPTION) && cmd.hasOption(SSID_OPTION)) {
      ap.createWifiNetwork(essid, password);
      return 1;
    }

    // if there are 'disable' and 'essid' arugments destroy Wi-Fi network
    if (cmd.hasOption(DISABLE_OPTION) && cmd.hasOption(SSID_OPTION)) {
      destroyNetwork(essid);
      return 1;
    }

    return 0;
  }

  private void destroyNetwork(String ssid) throws IOException {
    int result = ap.destroyWifiNetwork(ssid);
    if (result == 1) {
      writer.write("IWCONFIG: Сеть с заданным ESSID не может быть удалена\n");
    }
  }

  private void createNetwork (String ssid, String password) throws IOException {
    int result = ap.createWifiNetwork(ssid, password);
    if (result == 1) {
      writer.write("IWCONFIG: Сеть с заданным ESSID уже существует\n");
    }
    if (result == 2) {
      writer.write("IWCONFIG: Недопутимые аргументы\n");
    }
  }

  private void showStatus() throws IOException {
    String ssid = wifi.getSsidByPort(ap.getWifiPort(0));
    if (ssid == null) {
      // network is disabled, show message
      writer.write("Интерфейс: wlan0\nIEEE 802.11b\nСтатус: не активен\n");
    } else {
      String password = wifi.getPassword(ssid);

      // show message
      writer.write("Интерфейс: wlan0\nIEEE 802.11b\nStatus: активен\nESSID: "
              + ssid);
      if (password.equals("")) {
        writer.write("\nАутентификация: нет\n");
      } else {
        writer.write("\nПароль: " + password + "\n");
      }
    }
  }

  private void showHelp() {
    HelpFormatter formatter = new HelpFormatter();
    formatter.printHelp(new PrintWriter(writer),
            80,
            "iwconfig [-h] [-essid <essid>] [-p <password>] [-enable|disable]",
            "Настройка Wi-Fi интерфейса. Если не указано никаких аргументов "
            + "iwconfig выводит текущий статус Wi-Fi интерфейса.",
            options,
            3,
            2,
            null,
            false);
  }

  @Override
  public void setOutputWriter(Writer writer) {
    this.writer = writer;
  }
    
  @Override
  public void Stop() {
    // ignoring
  }
}
