/*
Computer Network Simulator (CNS)
Copyright (C) 2006 Maxim Tereshin <maxim-tereshin@yandex.ru>
Copyright (C) 2012 Igor A. Nebaev <opds@darkstar.su>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
*/

package org.netsimulator.net;

import java.util.logging.Logger;
import org.netsimulator.util.IdGenerator;

/**
 * Virtial wi-fi channel between 2 wi-fi devices
 */
public class WifiChannel {
  private final static Logger LOG =
          Logger.getLogger(WifiChannel.class.getName());

  private Media media;
  private String ssid;
  private String passwd;
  private WifiNetworks wifi;
  private Port apPort;
  private Router router;
  private int id;

  /**
   * Creates WifiChannel object binded to wi-fi interface of laptop.
   * @param idGenerator ID's generator
   * @param ssid SSID of channel
   * @param passwd password of SSID
   * @param iface router to which channel is binded
   */
  public WifiChannel(IdGenerator idGenerator, String ssid, String passwd,
          Router router) {
    this(idGenerator, idGenerator.getNextId(), ssid, passwd, router);
  }

  /**
   * Creates WifiChannel object binded to wi-fi interface of laptop.
   * @param idGenerator ID's generator
   * @param id id of wi-fi channel
   * @param ssid SSID of channel
   * @param passwd password of SSID
   * @param router router to which channel is binded
   */
  public WifiChannel(IdGenerator idGenerator, int id, String ssid,
          String passwd, Router router) {
    LOG.info("try to init wifi channel with ssid " + ssid
            + " and password " + passwd);

    this.id = id;
    this.ssid = ssid;

    if (passwd == null) {
      this.passwd = "";
    } else {
      this.passwd = passwd;
    }

    this.router = router;
    Interface wifiIface = router.getInterface(IP4Router.WLAN_IF_NAME);

    media = new Media(idGenerator);

    wifi = WifiNetworks.getInstance();
    try {
      media.connectToDevice((NetworkDevice) wifiIface);
    } catch (TooManyConnectionsException e) {
      LOG.severe("too many connections");
    }
  }

  /**
   * Returns ESSID.
   * @return ESSID
   */
  public String getSsid() {
    return ssid;
  }

  /**
   * Returns password.
   * @return password
   */
  public String getPassword() {
    return passwd;
  }

  /**
   * Returns current Media.
   * @return Media object
   */
  public Media getMedia() {
    return media;
  }

  /**
   * Returns client Wi-Fi device (laptop)
   * @return router
   */
  public Router getRouter() {
    return router;
  }

  /**
   * Returns AP port
   * @return port
   */
  public Port getPort() {
    return apPort;
  }

  /**
   * Disconnects from all devices.
   */
  public void destroyChannel() {
    LOG.info("try to destroy channel with ssid " + ssid);
    media.disconnectAll();
    wifi.removeChannel(ssid, this);
  }

  /**
   * Returns channel ID.
   * @return ID
   */
  public int getId() {
    return id;
  }



  /**
   * Creates channel with virtual port of proper AP (with the same SSID)
   * @return 0 - channel is created, 1 - no free AP virtual port, 2 - no such
   * SSID, 3 - port has been already connected to virtual AP port,
   * 4 - invalid password
   */
  // multithreading error threat, need to be hanled later !!!
  public int createChannel() {
    LOG.info("try to create wifi channel with ssid " + ssid);
    if (!wifi.checkSsid(ssid)) {
      LOG.info("no such ssid");
      return 2;
    }

    if (media.getCountConnectedDevices() > 1) {
      LOG.info("port has been already connected to virtual AP port");
      return 3;
    }

    Port port = wifi.getFreeApPort(ssid);
    if (port == null) {
      LOG.info("no free AP virtual port");
      return 1;
    }

    if(!passwd.equals(wifi.getPassword(ssid))) {
      // invalid password
      LOG.info("invalid password");
      return 4;
    }
    
    try {
      media.connectToDevice(port);
      apPort = port;
      wifi.addWifiChannel(ssid, this);
      LOG.info("wifi channel was created");
    } catch (TooManyConnectionsException e) {
      LOG.severe("too many connections");
    }

    return 0;
  }

}
