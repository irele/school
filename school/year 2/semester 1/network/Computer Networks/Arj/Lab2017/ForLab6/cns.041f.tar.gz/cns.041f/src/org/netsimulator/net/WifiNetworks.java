/*
Computer Network Simulator (CNS)
Copyright (C) 2006 Maxim Tereshin <maxim-tereshin@yandex.ru>
Copyright (C) 2012 Igor A. Nebaev <opds@darkstar.su>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
*/

package org.netsimulator.net;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Describes status of all wifi networks
 */
public class WifiNetworks {
  private final static Logger LOG =
          Logger.getLogger(WifiNetworks.class.getName());

  private static WifiNetworks instance;

  // String - ssid, ApPortsId - Wi-Fi virtual ports IDs
  private Map<String, ApPorts> networks;

  // the first String - ssid, the second one - password for connecting
  private Map<String, String> passwords;
  
  // the first String - ssid, the second one - connected channels
  private Map<String, Channels> channels;
  
  /**
   * Returns instance of WiFiNetworks class.
   * @return instance of WiFiNetworks class
   */
  public static WifiNetworks getInstance() {
    if (instance == null) {
      instance = new WifiNetworks();
    }
    return instance;
  }

  private WifiNetworks() {
    networks = new HashMap<String, ApPorts>();
    passwords = new HashMap<String, String>();
    channels = new HashMap<String, Channels>();
  }

  /**
   * Creates Wi-Fi network with target SSID, password. Attaches virtual
   * ports to this network.
   * @param ssid target SSID
   * @param apPorts Virtual ports should be attached to network
   * @param passwd target password
   * @return '0' - network was created, '1' - failed to create network: network
   * with target SSID has been already existed, '2' - bad arguments
   */
  public int createNetwork(String ssid, ArrayList<Port> apPorts, String passwd) {
    LOG.info("try to create network with ssid: " + ssid);
    if ((ssid == null) || (ssid.trim().equals(""))) {
      return 2;
    }

    if (apPorts.size() < 1) {
      return 2;
    }

    if (checkSsid(ssid)) {
      return 1;
    }

    String password = passwd;
    if ((password == null) || password.trim().equals("")) {
      password = "";
    }

    networks.put(ssid, new ApPorts(apPorts));
    passwords.put(ssid, password);
    channels.put(ssid, new Channels());

    LOG.info("network with ssid: " + ssid + " was created");

    return 0;
  }

  /**
   * Creates Wi-Fi network with target SSID, password (only for serialization)
   * @param ssid target SSID
   * @param passwd target password
   */
  public void createNetwork(String ssid, String passwd) {
    LOG.info("try to create network with ssid: " + ssid);

    networks.put(ssid, new ApPorts());
    passwords.put(ssid, passwd);
    channels.put(ssid, new Channels());

    LOG.info("network with ssid: " + ssid + " was created");
  }

  /**
   * Destroys Wi-Fi network with target SSID
   * @param ssid target SSID
   * @return 'true' - network was destroyed, 'false' - no network with such
   * SSID
   */
  public boolean destroyNetwork(String ssid) {
    LOG.info("try to destroy network with ssid: " + ssid);
    if ((ssid == null) || (ssid.trim().equals(""))) {
      return false;
    }
    
    if (!checkSsid(ssid)) {
      return false;
    }
    
    ArrayList<WifiChannel> chs = getWifiChannels(ssid);
    WifiChannel ch = null;
    for(Iterator<WifiChannel> i = chs.iterator(); i.hasNext(); ) {
      ch = i.next();
      try {
        ch.getRouter().getInterface(IP4Router.WLAN_IF_NAME)
                .setStatus(Interface.DOWN);
      } catch (ChangeInterfacePropertyException e) {
        return false;
      }
      ch.getRouter().destroyWifiChannel();
    }

    networks.remove(ssid);
    passwords.remove(ssid);
    channels.remove(ssid);

    LOG.info("network with ssid: " + ssid + " was destroyed");
    
    // DISABLE ALL LINKS
    return true;
  }

  /**
   * Returns ID's of all virtual AP ports.
   * @return array of ID's
   */
  public int[] getApPortsId(String ssid) {
    return networks.get(ssid).getPortsId();
  }

  /**
   * Returns ID's of all Wi-Fi channels.
   * @return array of ID's
   */
  public int[] getChannelsId(String ssid) {
    return channels.get(ssid).getChannelsId();
  }

  /**
   * Returns all virtual ports belonging to target SSID.
   * @param ssid target SSID
   * @return virtual ports belonging to target SSID
   */
  public ArrayList<Port> getApPorts(String ssid) {
    if ((ssid == null) || (ssid.trim().equals(""))) {
      return null;
    }

    if (!checkSsid(ssid)) {
      return null;
    }

    return networks.get(ssid).getPorts();
  }

  /**
   * Returns all Wi-Fi channels belonging to target SSID.
   * @param ssid target SSID
   * @return channels belonging to target SSID
   */
  public ArrayList<WifiChannel> getWifiChannels(String ssid) {
    if ((ssid == null) || (ssid.trim().equals(""))) {
      return null;
    }

    if (!checkSsid(ssid)) {
      return null;
    }

    return channels.get(ssid).getChannels();
  }

  /**
   * Adds Wi-Fi channel.
   * @param ssid target SSID
   * @param channel Wi-Fi channel
   */
  public void addWifiChannel(String ssid, WifiChannel channel) {
    LOG.info("add wifi channel " + channel.getId() + " to " + ssid);
    channels.get(ssid).addChannel(channel);
    try {
      LOG.info("status UP");
      channel.getRouter().getInterface(IP4Router.WLAN_IF_NAME)
                .setStatus(Interface.UP);
      } catch (ChangeInterfacePropertyException e) {
        LOG.info("EXCEPTION UP");
        return;
      }
  }

  /**
   * Adds AP port.
   * @param ssid target SSID
   * @param port port
   */
  public void addApPort(String ssid, Port port) {
    //LOG.info("add port with id " + port.getId() + " to " + ssid);
    networks.get(ssid).addPort(port);
  }

  /**
   * Removes Wi-Fi channel.
   * @param ssid target SSID
   * @param channel Wi-Fi channel
   */
  public void removeChannel(String ssid, WifiChannel channel) {
    LOG.info("remove wifi channel from " + ssid);
    if(checkSsid(ssid)) {
      channels.get(ssid).removeChannel(channel);
    }
  }
  
  /**
   * Returns SSID of Wi-Fi network based on belonging virtual port.
   * @param id virtual port
   * @return SSID if the network with target port is existed, 'null' in other
   * cases
   */
  public String getSsidByPort(Port port) {
    for (Map.Entry<String,ApPorts> entry : networks.entrySet()) {
      if (entry.getValue().contains(port)) {
        return entry.getKey();
      }
    }
    return null;
  }

  /**
   * Returns password required to connect to the target Wi-Fi network.
   * @param ssid target network
   * @return password
   */
  public String getPassword(String ssid) {
    String password = "";
    if (passwords.containsKey(ssid)) {
      return passwords.get(ssid);
    }
    return password;
  }

  /**
   * Return the port belonging to Wi-Fi network with target SSID and index.
   * @param ssid target SSID
   * @param index order number of the port.
   * @return virtual port
   */
  public Port getApPort(String ssid, int index) {
    if ((ssid == null) || (ssid.trim().equals(""))) {
      return null;
    }

    if (!checkSsid(ssid)) {
      return null;
    }

    if((index < 0) || (index > (networks.get(ssid).getSize() - 1))) {
      return null;
    }
    
    return networks.get(ssid).getPort(index);
  }

  /**
   * Returns all SSID of all created networks.
   * @return array of SSID
   */
  public String[] getAllSsid() {
    String[] result = new String[networks.size()];
    int i = 0;
    for (Map.Entry<String, ApPorts> entry : networks.entrySet()) {
      result[i] = entry.getKey();
      i++;
    }
    return result;
  }

  /**
   * Returns free (not connected) virtual AP port with specified ID.
   * @param ssid target SSID
   * @return virtual port
   */
  public Port getFreeApPort(String ssid) {
    Port port = null;
    for(int i = 0; i < networks.get(ssid).getSize(); i++) {
      port = networks.get(ssid).getPort(i);
      if(!port.isConnectedToMedia()) {
        return port;
      }
    }
    return null;
  }

  /**
   * Check if Wi-Fi network with target SSID is existed
   * @param ssid target SSID
   * @return 'true' if the network is existed.
   */
  public boolean checkSsid(String ssid) {
    return networks.containsKey(ssid);
  }

  // AP virtual Wi-Fi ports
  private class ApPorts {
    private ArrayList<Port> ports;

    public ApPorts(ArrayList<Port> ports) {
      this.ports = ports;
    }

    public ApPorts() {
      ports = new ArrayList<Port>();
    }

    public void addPort(Port port) {
      ports.add(port);
    }

    public int getSize() {
      return ports.size();
    }

    public Port getPort(int index) {
      if ((index > (ports.size() - 1)) || (index < 0)) {
        return null;
      } else {
        return ports.get(index);
      }
    }

    public ArrayList<Port> getPorts() {
      return ports;
    }

    public int[] getPortsId() {
      int size = ports.size();
      int[] result = new int[size];
      for(int i = 0; i < size; i++) {
        result[i] = ports.get(i).getId();
      }
      return result;
    }

    public boolean contains(Port port) {
      if (ports.contains(port)) {
        return true;
      }
      return false;
    }
  }
  
  // Wi-Fi channels
  private class Channels {
    private ArrayList<WifiChannel> channels;

    public Channels() {
      channels = new ArrayList<WifiChannel>();
    }

    public ArrayList<WifiChannel> getChannels() {
      return channels;
    }

    public int[] getChannelsId() {
      int size = channels.size();
      if(size == 0) {
        return null;
      }
      int[] result = new int[size];
      for(int i = 0; i < size; i++) {
        result[i] = channels.get(i).getId();
      }
      return result;
    }

    public boolean contains(WifiChannel channel) {
      if (channels.contains(channel)) {
        return true;
      }
      return false;
    }

    public void addChannel(WifiChannel channel) {
      if (!contains(channel)) {
        channels.add(channel);
      }
    }

    public void removeChannel(WifiChannel channel) {
      if (contains(channel)) {
        channels.remove(channel);
      }
    }
  }
  
}
