package org.netsimulator.util;

public class XMLHelper
{
    public static final String vendorParserClass =
                    "org.apache.xerces.parsers.SAXParser";
    
    public static final String charsetName = "UTF-8";

    private XMLHelper() {
    }
    
}
