/*
Computer Network Simulator (CNS)
Copyright (C) 2006 Maxim Tereshin <maxim-tereshin@yandex.ru>
Copyright (C) 2012 Igor A. Nebaev <opds@darkstar.su>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
*/
package org.netsimulator.net;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Logger;
import org.netsimulator.util.IdGenerator;

/**
 * Wi-Fi Access Point.
 */
public class AP implements Concentrator {
  private static final Logger logger =
          Logger.getLogger("org.netsimulator.net.AP");

  private static final int MAX_WIFI_CONNECTIONS = 20;
  private static final int ETHERNET_PORTS_COUNT = 1;

  private int id;
  private IdGenerator idGenerator;
  private ArrayList<Port> ports;

  private WifiNetworks wifi;

  /**
   * Creates AP.
   */
  public AP(IdGenerator idGenerator) {
    this(idGenerator, idGenerator.getNextId());
  }

  public AP(IdGenerator idGenerator, int id) {
    this.idGenerator = idGenerator;
    this.id = id;

    wifi = WifiNetworks.getInstance();

    ports = new ArrayList<Port>();

    // add Ethernet port
    ports.add(new Port(idGenerator, this));

    // add virtual WiFi ports
    for (int i = 0; i < MAX_WIFI_CONNECTIONS; i++) {
      ports.add(new Port(idGenerator, this));
    }
  }

  /**
   * Destroys Wi-Fi network.
   */
  public void destroyWifiNetwork() {
    String ssid = wifi.getSsidByPort(getWifiPort(0));
    if (ssid != null) {
      wifi.destroyNetwork(ssid);
    }
  }

  /**
   * Destroys Wi-Fi network.
   * @param ssid target ESSID
   * @return 0 - network was destroyed, 1 - network can't be destroyed
   */
  public int destroyWifiNetwork(String ssid) {
    if ( !ssid.equals(wifi.getSsidByPort(getWifiPort(0))) ) {
      return 1;
    }

    boolean result = wifi.destroyNetwork(ssid);
    if (result == false) {
      // no network with such SSID
      return 1;
    }
    
    return 0;
  }

  /**
   * Creates Wi-Fi network.
   * @param ssid target ESSID
   * @param password target password
   * @return '0' - network was created, '1' - failed to create network: network
   * with target SSID has been already existed, '2' - bad arguments
   */
  public int createWifiNetwork(String ssid, String password) {
    return wifi.createNetwork(ssid, getWifiPorts(), password);
  }


  @Override
  public int getPortsCount() {
    // get ethernet ports count!
    return ETHERNET_PORTS_COUNT;
  }

  @Override
  public Port getPort(int port) {
    // get ethernet port!
    return ports.get(0);
  }

  /**
   * Returns Wi-Fi virtual port with specified index.
   * @param index index of virtual port
   * @return virtual Wi-Fi port
   */
  public Port getWifiPort(int index) {
    return ports.get(index + 1);
  }

  /**
   * Returns all virtual Wi-Fi ports.
   * @return all virtual Wi-Fi ports
   */
  public ArrayList<Port> getWifiPorts() {
    ArrayList<Port> list = new ArrayList<Port>();
    for(int i = 1; i < ports.size(); i++) {
      list.add(ports.get(i));
    }
    return list;
  }

  @Override
  public Port getPortById(int id) {
    Port port = null;
    for(Iterator<Port> i = ports.iterator(); i.hasNext(); ) {
      port = i.next();
      if(port.getId() == id) {
        return port;
      }
    }

    // nothing was found
    return null;
  }

  @Override
  public NetworkDevice getNetworkDeviceById(int id) {
    return getPortById(id);
  }

  @Override
  public void addPort(Port port) {
    ports.add(port);
    port.setConcentrator(this);
  }

  public Port[] getPorts() {
    Port[] array = new Port[ports.size()];
    for(int i = 0; i < ports.size(); i++) {
      array[i] = ports.get(i);
    }
    return array;
  }

  @Override
  public void transportPacket(Port sourcePort, Layer2Packet packet) {
    for(Iterator<Port> i = ports.iterator(); i.hasNext();) {
      Port port = i.next();
      if(port != sourcePort) {
        port.transmitPacket(packet);
      }
    }
  }

  @Override
  public int getId() {
    return id;
  }

  @Override
  public void setId(int id) {
    this.id = id;
  }

  public IdGenerator getIdGenerator() {
    return idGenerator;
  }

}
