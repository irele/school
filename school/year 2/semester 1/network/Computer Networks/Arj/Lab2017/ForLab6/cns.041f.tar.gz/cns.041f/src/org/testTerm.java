package org;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.netsimulator.term.TerminalFrame;

public class testTerm extends JFrame
{

    public static void main(String argv[]) throws FileNotFoundException, FontFormatException, IOException
    {
        new TerminalFrame();
    }
}
