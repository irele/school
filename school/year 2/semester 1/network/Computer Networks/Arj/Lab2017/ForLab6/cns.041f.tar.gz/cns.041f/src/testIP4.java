package org;
import org.netsimulator.net.AddressException;
import org.netsimulator.net.IP4Address;

public class testIP4
{
    public static void main(String argv[])
    {
        IP4Address address = null;

        try
        {
            address = new IP4Address(argv[0]);
        }catch(AddressException ae)
        {
            ae.printStackTrace();
            System.exit(1);
        }

        System.out.println(address);
    }
}
