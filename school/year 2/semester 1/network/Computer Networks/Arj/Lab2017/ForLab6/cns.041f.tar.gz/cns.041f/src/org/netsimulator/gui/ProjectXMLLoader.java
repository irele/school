/*
Computer Network Simulator (CNS)
Copyright (C) 2006 Maxim Tereshin <maxim-tereshin@yandex.ru>
Copyright (C) 2012 Igor A. Nebaev <opds@darkstar.su>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
            
This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
General Public License for more details.
            
You should have received a copy of the GNU General Public License along 
with this program; if not, write to the Free Software Foundation, 
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA 
*/

/*
 * ProjectXMLLoader.java
 *
 * Created on 14 May, 2006, 15:58
 */

package org.netsimulator.gui;

import java.io.*;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.logging.Logger;
import javax.swing.JProgressBar;
import org.netsimulator.net.AP;
import org.netsimulator.net.AddressException;
import org.netsimulator.net.ChangeInterfacePropertyException;
import org.netsimulator.net.Concentrator;
import org.netsimulator.net.EthernetInterface;
import org.netsimulator.net.Hub;
import org.netsimulator.net.IP4Address;
import org.netsimulator.net.IP4Router;
import org.netsimulator.net.Interface;
import org.netsimulator.net.MACAddress;
import org.netsimulator.net.Media;
import org.netsimulator.net.NetworkDevice;
import org.netsimulator.net.Port;
import org.netsimulator.net.RoutingTable;
import org.netsimulator.net.Switch;
import org.netsimulator.net.TooManyInterfacesException;
import org.netsimulator.net.WifiNetworks;
import org.netsimulator.util.ProjectDTDReferenceResolver;
import org.netsimulator.util.XMLHelper;
import org.xml.sax.*;
import org.xml.sax.helpers.XMLReaderFactory;

public class ProjectXMLLoader implements ContentHandler, Runnable
{
    private final static Logger LOG =
          Logger.getLogger(ProjectXMLLoader.class.getName());

    private XMLReader reader;
    private InputSource inputSource;
    private NetworkPanel panel;
    private Locator locator;
    private ErrorHandler errorHandler;
    private JProgressBar progressBar;
    private int linesCount;
    private ArrayList<ProjectXMLLoadingCompleteListener> loadingListeners = 
            new ArrayList<ProjectXMLLoadingCompleteListener>();
    
    private IP4Router currentRouter;
    private SocketsHolder currentSocketsHolder;
    private RouterHolder currentRouterHolder;
    private RoutingTable currentRoutingTable;
    private Concentrator currentConcentrator;
    private PatchcordNetworkLink currentPatchcord;
    private HubNetworkShape currentHubHolder;
    private ApNetworkShape currentApHolder;
    private SwitchNetworkShape currentSwitchHolder;
    private Switchx24NetworkShape currentSwitchx24Holder;
    private String currentSsid;

    private WifiNetworks wifi;

    // all AP's
    private ArrayList<AP> aps = new ArrayList<AP>();

    // all laptops
    // private ArrayList<IP4Router> laptops = new ArrayList<IP4Router>();
    private ArrayList<IP4Router> laptops = new ArrayList<IP4Router>();

    /** Creates a new instance of ProjectXMLSerializer */
    public ProjectXMLLoader(
            NetworkPanel panel, 
            ErrorHandler errorHandler,
            JProgressBar progressBar)
    {
        this.panel = panel;
        this.errorHandler = errorHandler;
        this.progressBar = progressBar;
    }
 
    
    
    public void setSourceFile(File sourceFile)
    throws SAXException, IOException
    {
        reader = XMLReaderFactory.createXMLReader(XMLHelper.vendorParserClass);
        
        reader.setFeature("http://xml.org/sax/features/validation", true);

        LineNumberReader lnr = new LineNumberReader(new FileReader(sourceFile));
        linesCount = 0;
        int curChar = -1;
        while((curChar = lnr.read()) >= 0 )
        {
            if(curChar == '\n')
            {
                linesCount++;
            }
        }
        lnr.close();
                
        inputSource = new InputSource(new FileInputStream(sourceFile));
        inputSource.setEncoding(XMLHelper.charsetName);

        reader.setContentHandler( this );
        reader.setErrorHandler( errorHandler );
        reader.setEntityResolver( new ProjectDTDReferenceResolver() );

        progressBar.setMinimum(0);
        progressBar.setMaximum(linesCount);
        progressBar.setStringPainted(true);
    }
    
    
  @Override
    public void skippedEntity(String name) throws SAXException
    {
    }

  @Override
    public void setDocumentLocator(Locator locator)
    {
        this.locator = locator;
    }

  @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
    }

  @Override
    public void startDocument() throws SAXException
    {
    }

  @Override
    public void processingInstruction(String target, String data) throws SAXException
    {
        System.out.println("PI target="+target+" data="+data);
    }

  @Override
    public void endDocument() throws SAXException
    {
        panel.repaint();
    }

  @Override
    public void startPrefixMapping(String prefix, String uri) throws SAXException
    {
    }

  @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException
    {
    }

  @Override
    public void endPrefixMapping(String prefix) throws SAXException
    {
    }
    
    

    
  @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) 
    throws SAXException
    {
        progressBar.setValue(locator.getLineNumber());
        
        if(qName.equals("project"))
        {
            loadProject(atts);
        }

        if(qName.equals("routerShape"))
        {
            startLoadingRouterShape(atts);
        }
        
        if(qName.equals("IP4Router"))
        {
            startLoadingIP4Router(atts);
        }

        if(qName.equals("apShape")) {
          startLoadingApShape(atts);
        }

        if(qName.equals("ap")) {
          startLoadingAp(atts);
        }

        if(qName.equals("laptopShape")) {
          startLoadingLaptopShape(atts);
        }

        if(qName.equals("laptop")) {
          startLoadingLaptop(atts);
        }

        if(qName.equals("hubShape"))
        {
            startLoadingHubShape(atts);
        }
        
        if(qName.equals("hub"))
        {
            startLoadingHub(atts);
        }
        
        if(qName.equals("patchcord"))
        {
            startLoadingPatchcord(atts);
        }
        
        if(qName.equals("media"))
        {
            loadMedia(atts);
        }


        if(qName.equals("plug"))
        {
            loadPlug(atts);
        }
        
        
        if(qName.equals("socketShape"))
        {
            loadSocketShape(atts);
        }

        if(qName.equals("hub"))
        {
            startLoadingHub(atts);
        }

        if(qName.equals("switchShape"))
        {
            startLoadingSwitchShape(atts);
        }
        

        if(qName.equals("switch"))
        {
            startLoadingSwitch(atts);
        }
        
         if(qName.equals("switchx24Shape"))
        {
            startLoadingSwitchx24Shape(atts);
        }
        

        if(qName.equals("switchx24"))
        {
            startLoadingSwitchx24(atts);
        }
        
        if(qName.equals("desktopShape"))
        {
            startLoadingDesktopShape(atts);
        }
        
         if(qName.equals("firewallShape"))
        {
            startLoadingFirewallShape(atts);
        }
         
        if(qName.equals("eth"))
        {
            loadEthernet(atts);
        }
        
        if(qName.equals("routingTable"))
        {
            startLoadingRoutingTable(atts);
        }
        
        if(qName.equals("row"))
        {
            loadRoutingTableRow(atts);
        }

        if(qName.equals("port"))
        {
            loadPort(atts);
        }

        if(qName.equals("channel")) {
          loadChannel(atts);
        }

        if(qName.equals("wifi")) {
          loadWifi(atts);
        }

        if(qName.equals("network")) {
          startLoadingNetwork(atts);
        }

        if(qName.equals("apPort")) {
          loadApPort(atts);
        }

        if(qName.equals("wifiChannel")) {
          loadConnectedWifiChannel(atts);
        }
    }

    
    
    
    
    
  @Override
    public void endElement(String uri, String localName, String qName) throws SAXException
    {
        progressBar.setValue(locator.getLineNumber());
        
        if(qName.equals("routerShape"))
        {
            endLoadingRouterShape();
        }

        if(qName.equals("IP4Router"))
        {
            endLoadingIP4Router();
        }

        if(qName.equals("apShape")) {
          endLoadingApShape();
        }

        if(qName.equals("ap")) {
          endLoadingAp();
        }

        if(qName.equals("laptopShape")) {
          endLoadingLaptopShape();
        }

        if(qName.equals("laptop")) {
          endLoadingLaptop();
        }

        if(qName.equals("hub"))
        {
            endLoadingHub();
        }
    
        if(qName.equals("hubShape"))
        {
            endLoadingHubShape();
        }
        
        
        if(qName.equals("switch"))
        {
            endLoadingSwitch();
        }
    
        if(qName.equals("switchShape"))
        {
            endLoadingSwitchShape();
        }

           if(qName.equals("switchx24"))
        {
            endLoadingSwitchx24();
        }
    
        if(qName.equals("switchx24Shape"))
        {
            endLoadingSwitchx24Shape();
        }
        
        if(qName.equals("desktopShape"))
        {
            endLoadingDesktopShape();
        }
        
           if(qName.equals("firewallShape"))
        {
            endLoadingFirewallShape();
        }

        if(qName.equals("routingTable"))
        {
            endLoadingRoutingTable();
        }

        if(qName.equals("patchcord"))
        {
            endLoadingPatchcord();
        }

        if(qName.equals("network")) {
          endLoadingNetwork();
        }
    
    }

    private void startLoadingNetwork(Attributes atts) throws SAXException {
      String ssid = atts.getValue("ssid");
      String passwd = atts.getValue("passwd");
      currentSsid = ssid;
      wifi.createNetwork(ssid, passwd);
    }

    private void endLoadingNetwork() {
      currentSsid = null;
    }

    private void loadApPort(Attributes atts) throws SAXException{
      int id = -1;
      try {
        id = Integer.parseInt(atts.getValue("portId"));
      } catch(NumberFormatException nfe) {
        throw new SAXException(nfe);
      }

      AP ap = null;
      Port port = null;
      for (Iterator<AP> i = aps.iterator(); i.hasNext();) {
        ap = i.next();
        port = ap.getPortById(id);
        if (port != null) {
          wifi.addApPort(currentSsid, port);
          return;
        }
      }
    }

    private void loadConnectedWifiChannel(Attributes atts) throws SAXException {
      int id = -1;
      try {
        id = Integer.parseInt(atts.getValue("id"));
      } catch(NumberFormatException nfe) {
        throw new SAXException(nfe);
      }
      
      IP4Router laptop = null;
      for (Iterator<IP4Router> i = laptops.iterator(); i.hasNext();) {
        laptop = i.next();
        if(laptop.hasWifiChannel()
                && (laptop.getWifiChannel().getId() == id)) {
          
          EthernetInterface eth = (EthernetInterface)laptop.getInterface(IP4Router.WLAN_IF_NAME);
          
          wifi.addWifiChannel(currentSsid, laptop.getWifiChannel());
          laptop.getWifiChannel().createChannel();
          return;
        }
      }
    }

    private void loadWifi(Attributes atts) throws SAXException {
      wifi = WifiNetworks.getInstance();
    }

    private void startLoadingRouterShape(Attributes atts)
    throws SAXException
    {
        try
        {
            int id=0; 
            int x=20, y=20;
            String description="", name="";
            
            for(int i=0; i<atts.getLength(); i++)
            {
                String attr = atts.getQName(i);

                if(attr.equals("id"))
                {
                    id = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("x"))
                {
                    x = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("y"))
                {
                    y = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("description"))
                {
                    description = atts.getValue(i);
                }
                if(attr.equals("name"))
                {
                    name = atts.getValue(i);
                }
            }
            
            RouterNetworkShape new_shape = null ;
            try
            {
                new_shape = new RouterNetworkShape(panel, id);
            }catch(InterruptedException ie)
            {
                ie.printStackTrace();
            }
            panel.putOnDevicesLayer(new_shape);

            new_shape.setName(name);
            new_shape.setComment(description);
            new_shape.setLocation(x, y);

            panel.repaint();            
            
            currentSocketsHolder = new_shape;
            currentRouterHolder = new_shape;
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }
    


    
    
    
    
    private void startLoadingDesktopShape(Attributes atts)
    throws SAXException
    {
        try
        {
            int id=0; 
            int x=20, y=20;
            String description="", name="";
            
            for(int i=0; i<atts.getLength(); i++)
            {
                String attr = atts.getQName(i);

                if(attr.equals("id"))
                {
                    id = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("x"))
                {
                    x = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("y"))
                {
                    y = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("description"))
                {
                    description = atts.getValue(i);
                }
                if(attr.equals("name"))
                {
                    name = atts.getValue(i);
                }
            }
            
            DesktopNetworkShape new_shape = null ;
            try
            {
                new_shape = new DesktopNetworkShape(panel, id);
            }catch(InterruptedException ie)
            {
                ie.printStackTrace();
            }
            panel.putOnDevicesLayer(new_shape);

            new_shape.setName(name);
            new_shape.setComment(description);
            new_shape.setLocation(x, y);

            panel.repaint();            
            
            currentSocketsHolder = new_shape;
            currentRouterHolder = new_shape;
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }
     
     private void startLoadingFirewallShape(Attributes atts)
    throws SAXException
    {
        try
        {
            int id=0; 
            int x=20, y=20;
            String description="", name="";
            
            for(int i=0; i<atts.getLength(); i++)
            {
                String attr = atts.getQName(i);

                if(attr.equals("id"))
                {
                    id = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("x"))
                {
                    x = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("y"))
                {
                    y = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("description"))
                {
                    description = atts.getValue(i);
                }
                if(attr.equals("name"))
                {
                    name = atts.getValue(i);
                }
            }
            
            FirewallNetworkShape new_shape = null ;
            try
            {
                new_shape = new FirewallNetworkShape(panel, id);
            }catch(InterruptedException ie)
            {
                ie.printStackTrace();
            }
            panel.putOnDevicesLayer(new_shape);

            new_shape.setName(name);
            new_shape.setComment(description);
            new_shape.setLocation(x, y);

            panel.repaint();            
            
            currentSocketsHolder = new_shape;
            currentRouterHolder = new_shape;
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }
    
    private void startLoadingLaptopShape(Attributes atts) throws SAXException {
      try {
        int id=0;
        int x=20, y=20;
        String description="", name="";

        for(int i=0; i<atts.getLength(); i++) {
          String attr = atts.getQName(i);

          if(attr.equals("id")) {
            id = Integer.parseInt(atts.getValue(i));
          }

          if(attr.equals("x")) {
            x = Integer.parseInt(atts.getValue(i));
          }

          if(attr.equals("y")) {
            y = Integer.parseInt(atts.getValue(i));
          }

          if(attr.equals("description")) {
            description = atts.getValue(i);
          }

          if(attr.equals("name")) {
            name = atts.getValue(i);
          }
        }

        LaptopNetworkShape new_shape = null;
        try {
          new_shape = new LaptopNetworkShape(panel, id);
        } catch(InterruptedException ie) {
          ie.printStackTrace();
        }
        panel.putOnDevicesLayer(new_shape);

        new_shape.setName(name);
        new_shape.setComment(description);
        new_shape.setLocation(x, y);

        panel.repaint();

        currentSocketsHolder = new_shape;
        currentRouterHolder = new_shape;
      } catch(Exception e) {
        throw new SAXException(e);
      }
    }

    private void endLoadingLaptopShape() {
      currentSocketsHolder = null;
      currentRouterHolder = null;
    }

    private void startLoadingLaptop(Attributes atts) throws SAXException {
      int id = -1;
      try {
        id = Integer.parseInt(atts.getValue("id"));
      } catch(NumberFormatException nfe) {
        throw new SAXException(nfe);
      }

      IP4Router router = null;

      try {
        router = new IP4Router(panel.getIdGenerator(), 0, id, true);
      } catch(TooManyInterfacesException tmie) {
        throw new SAXException(tmie);
      }

      currentRouterHolder.setRouter(router);
      currentRouter = router;
    }

    private void endLoadingLaptop() {
      laptops.add(currentRouter);
      currentRouter = null;
      

    }

    private void startLoadingIP4Router(Attributes atts)
    throws SAXException
    {
        int id = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }    
     
        IP4Router router = null;
        
        try
        {
            router = new IP4Router(panel.getIdGenerator(), 0, id, false);
        }catch(TooManyInterfacesException tmie)
        {
            throw new SAXException(tmie);
        }
        
        currentRouterHolder.setRouter(router);
        currentRouter = router;
    }
    
    
    
    
    
    
    private void endLoadingIP4Router()
    {
      currentRouter = null;
    }

    private void loadChannel(Attributes atts) throws SAXException {
      int id=0;
      String ssid = "";
      String passwd = "";

      for(int i=0; i<atts.getLength(); i++) {
        String attr = atts.getQName(i);

        if(attr.equals("id")) {
          try {
            id = Integer.parseInt(atts.getValue(i));
          } catch(NumberFormatException nfe) {
            throw new SAXException(nfe);
          }
        }

        if(attr.equals("ssid")) {
          ssid = atts.getValue(i);
        }

        if(attr.equals("passwd")) {
          passwd = atts.getValue(i);
        }
      }

      currentRouter.setWifiChannel(ssid, passwd, id);
    }

    private void startLoadingPatchcord(Attributes atts)
    throws SAXException
    {
        int id = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }    
     
        PatchcordNetworkLink link = 
                new PatchcordNetworkLink(panel, id);
        currentPatchcord = link;
    }    
    
    
 
    
    
    private void endLoadingPatchcord()
    {
        currentPatchcord = null;
    }
    
    
    
    
    
    
    private void startLoadingSwitchShape(Attributes atts)
    throws SAXException
    {
        try
        {
            int id=0;
            int x=20, y=20;
            String description="", name="";
            
            for(int i=0; i<atts.getLength(); i++)
            {
                String attr = atts.getQName(i);

                if(attr.equals("id"))
                {
                    id = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("x"))
                {
                    x = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("y"))
                {
                    y = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("description"))
                {
                    description = atts.getValue(i);
                }
                if(attr.equals("name"))
                {
                    name = atts.getValue(i);
                }
            }

            SwitchNetworkShape new_shape = null ;
            try
            {
                new_shape = new SwitchNetworkShape(panel, id);
            }catch(InterruptedException ie)
            {
                ie.printStackTrace();
            }
            panel.putOnDevicesLayer(new_shape);

            new_shape.setName(name);
            new_shape.setComment(description);
            new_shape.setLocation(x, y);
        
            panel.repaint();                        
            
            currentSocketsHolder = new_shape;
            currentSwitchHolder = new_shape;
            
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }
    
 private void startLoadingSwitchx24Shape(Attributes atts)
    throws SAXException
    {
        try
        {
            int id=0;
            int x=20, y=20;
            String description="", name="";
            
            for(int i=0; i<atts.getLength(); i++)
            {
                String attr = atts.getQName(i);

                if(attr.equals("id"))
                {
                    id = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("x"))
                {
                    x = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("y"))
                {
                    y = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("description"))
                {
                    description = atts.getValue(i);
                }
                if(attr.equals("name"))
                {
                    name = atts.getValue(i);
                }
            }

            Switchx24NetworkShape new_shape = null ;
            try
            {
                new_shape = new Switchx24NetworkShape(panel, id);
            }catch(InterruptedException ie)
            {
                ie.printStackTrace();
            }
            panel.putOnDevicesLayer(new_shape);

            new_shape.setName(name);
            new_shape.setComment(description);
            new_shape.setLocation(x, y);
        
            panel.repaint();                        
            
            currentSocketsHolder = new_shape;
            currentSwitchx24Holder = new_shape;
            
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }
    

    
    private void startLoadingSwitch(Attributes atts)
    throws SAXException
    {
        int id = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }    
     
        Switch _switch_ = null;
        _switch_ = new Switch(panel.getIdGenerator(), 0, id);
        currentSwitchHolder.setSwitch(_switch_);
        currentConcentrator = _switch_;
    }
    
     
  private void startLoadingSwitchx24(Attributes atts)
    throws SAXException
    {
        int id = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }    
     
        Switch _switch_ = null;
        _switch_ = new Switch(panel.getIdGenerator(), 0, id);
        currentSwitchx24Holder.setSwitch(_switch_);
        currentConcentrator = _switch_;
    }

    
    private void endLoadingSwitch()
    {
        currentConcentrator = null;
    }
    
    
    private void endLoadingSwitchx24()
    {
        currentConcentrator = null;
    }
        
    
    
    
    
    
    private void startLoadingHubShape(Attributes atts)
    throws SAXException
    {
        try
        {
            int id=0;
            int x=20, y=20;
            String description="", name="";
            
            for(int i=0; i<atts.getLength(); i++)
            {
                String attr = atts.getQName(i);

                if(attr.equals("id"))
                {
                    id = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("x"))
                {
                    x = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("y"))
                {
                    y = Integer.parseInt(atts.getValue(i));
                }
                if(attr.equals("description"))
                {
                    description = atts.getValue(i);
                }
                if(attr.equals("name"))
                {
                    name = atts.getValue(i);
                }
            }
            

            HubNetworkShape new_shape = null ;
            try
            {
                new_shape = new HubNetworkShape(panel, id);
            }catch(InterruptedException ie)
            {
                ie.printStackTrace();
            }
            panel.putOnDevicesLayer(new_shape);

            new_shape.setName(name);
            new_shape.setComment(description);
            new_shape.setLocation(x, y);
        
            panel.repaint();                        
            
            currentSocketsHolder = new_shape;
            currentHubHolder = new_shape;
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }
        
    
    
    
    private void endLoadingHubShape()
    {
        currentSocketsHolder = null;
        currentHubHolder = null;
    }    
    
    
    
    
    
    private void startLoadingHub(Attributes atts)
    throws SAXException
    {
        int id = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }    
     
        Hub hub = null;
        hub = new Hub(panel.getIdGenerator(), 0, id);
        currentHubHolder.setHub(hub);
        currentConcentrator = hub;
    }
    
    
    
    
    
    
    private void endLoadingHub()
    {
        currentConcentrator = null;
    }
        
    private void startLoadingApShape(Attributes atts) throws SAXException {
      try {
        int id=0;
        int x=20, y=20;
        String description="", name="";

        for(int i = 0; i < atts.getLength(); i++) {
          String attr = atts.getQName(i);

          if(attr.equals("id")) {
            id = Integer.parseInt(atts.getValue(i));
          }

          if(attr.equals("x")) {
            x = Integer.parseInt(atts.getValue(i));
          }

          if(attr.equals("y")) {
            y = Integer.parseInt(atts.getValue(i));
          }

          if(attr.equals("description")) {
            description = atts.getValue(i);
          }

          if(attr.equals("name")) {
            name = atts.getValue(i);
          }
        }

        ApNetworkShape new_shape = null ;
        try {
          new_shape = new ApNetworkShape(panel, id);
        } catch(InterruptedException ie) {
          ie.printStackTrace();
        }
        panel.putOnDevicesLayer(new_shape);

        new_shape.setName(name);
        new_shape.setComment(description);
        new_shape.setLocation(x, y);

        panel.repaint();

        currentSocketsHolder = new_shape;
        currentApHolder = new_shape;
      } catch(Exception e) {
        throw new SAXException(e);
      }
    }

    private void endLoadingApShape() {
      currentSocketsHolder = null;
      currentHubHolder = null;
    }

    private void startLoadingAp(Attributes atts) throws SAXException {
      int id = -1;
      try {
        id = Integer.parseInt(atts.getValue("id"));
      } catch(NumberFormatException nfe) {
        throw new SAXException(nfe);
      }

      AP ap = null;
      ap = new AP(panel.getIdGenerator(), id);
      currentApHolder.setAp(ap);
      currentConcentrator = ap;
    }

    private void endLoadingAp() {
      aps.add( (AP)currentConcentrator);
      currentConcentrator = null;
    }
    
    
    private void startLoadingRoutingTable(Attributes atts)
    {
        currentRoutingTable = currentRouter.getRoutingTable();
    }
    
    
    private void endLoadingRouterShape()
    {
        currentSocketsHolder = null;
        currentRouterHolder = null;
    }
    

    private void endLoadingDesktopShape()
    {
        currentSocketsHolder = null;
        currentRouterHolder = null;
    }

  private void endLoadingFirewallShape()
    {
        currentSocketsHolder = null;
        currentRouterHolder = null;
    }

    private void endLoadingSwitchShape()
    {
        currentSocketsHolder = null;
        currentSwitchHolder = null;
    }
 
    private void endLoadingSwitchx24Shape()
    {
        currentSocketsHolder = null;
        currentSwitchx24Holder = null;
    }
    
    private void endLoadingRoutingTable()
    {
        currentRoutingTable = null;
    }
    
    
    private void loadProject(Attributes atts)
    throws SAXException
    {
        for(int i=0; i<atts.getLength(); i++)
        {
            String attr = atts.getQName(i);
            
            if(attr.equals("author"))
            {
                panel.setAuthor(atts.getValue(i));
            }

            if(attr.equals("description"))
            {
                panel.setDescription(atts.getValue(i));
            }

            if(attr.equals("createDate"))
            {
                panel.setCreateDate(atts.getValue(i));
            }
            
            if(attr.equals("currentId"))
            {
                int initValue = 0;
                try
                {
                    initValue = Integer.parseInt(atts.getValue(i));
                }catch(NumberFormatException nfe)
                {
                    throw new SAXException(nfe);
                }
                panel.getIdGenerator().setInitValue(initValue);
            }
        }
    }
    
    
    
    
    
    
    private void loadEthernet(Attributes atts)
    throws SAXException
    {
        IP4Address address = null;
        IP4Address netmask = null;
        IP4Address broadcast = null;
        int status = Interface.UNKNOWN;
        int bandwidth = 0;
        String name = atts.getValue("name");
        MACAddress mac = null;
        try {
            mac = new MACAddress(atts.getValue("mac"));
        } catch (AddressException ae) {
            throw new SAXException(ae);
        }

        int id = -1;
        try {
            id = Integer.parseInt(atts.getValue("id"));
        } catch (NumberFormatException nfe) {
            throw new SAXException(nfe);
        }

        EthernetInterface eth = new EthernetInterface(panel.getIdGenerator(), id, mac, name);
        currentRouter.addInterface(eth);
        for (int i = 0; i < atts.getLength(); i++) {
            String attr = atts.getQName(i);

            if (attr.equals("status")) {
                status = Integer.parseInt(atts.getValue(i));
            }

            try {
                if (attr.equals("ip4") && atts.getValue(i).length() != 0) {
                    address = new IP4Address(atts.getValue(i));
                }

                if (attr.equals("ip4bcast") && atts.getValue(i).length() != 0) {
                    broadcast = new IP4Address(atts.getValue(i));
                }

                if (attr.equals("ip4mask") && atts.getValue(i).length() != 0) {
                    netmask = new IP4Address(atts.getValue(i));
                }
            } catch (AddressException ae) {
                throw new SAXException(ae);
            }
            if (attr.equals("bandwidth") && atts.getValue(i).length() != 0) {
                bandwidth = Integer.parseInt(atts.getValue(i));
            }
        }

        try 
        {
            eth.setInetAddress(address);
            eth.setNetmaskAddress(netmask);
            eth.setBroadcastAddress(broadcast);
            eth.setBandwidth(bandwidth);
            if (status != Interface.UNKNOWN) 
            {
                eth.setStatus(status);
            }

        } catch ( ChangeInterfacePropertyException e ) 
        {
          throw new SAXException( e );
        }
    }    
    
    
    

 
    
    
    private void loadSocketShape(Attributes atts)
    throws SAXException
    {
        int id = -1, x = -1, y = -1, devId = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
            x = Integer.parseInt(atts.getValue("x"));
            y = Integer.parseInt(atts.getValue("y"));
            devId = Integer.parseInt(atts.getValue("devId"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }
        
        NetworkDevice dev = 
                currentSocketsHolder.getNetworkDeviceHolder()
                .getNetworkDeviceById(devId);
        
        //NetworkDevice dev = (NetworkDevice)panel.getDeviceById(devId);
        
        SocketNetworkShape socket = null;
        try
        {
            socket = new SocketNetworkShape(dev, panel, id);
        }catch(InterruptedException ie)
        {
            throw new SAXException(ie);
        }

        currentSocketsHolder.addSocket(socket);
    }    
        
    

    
    
    private void loadMedia(Attributes atts)
    throws SAXException
    {
        int id = -1, pointsCount = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
            pointsCount = Integer.parseInt(atts.getValue("pointsCount"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }
        
        Media media = new Media(panel.getIdGenerator(), pointsCount, id);

        currentPatchcord.setMedia(media);
    }    
        
    
    


    private void loadPlug(Attributes atts)
    throws SAXException
    {
        int 
                id = -1, 
                x = -1, 
                y = -1, 
                point = -1;
        try
        {
            id = Integer.parseInt(atts.getValue("id"));
            x = Integer.parseInt(atts.getValue("x"));
            y = Integer.parseInt(atts.getValue("y"));
            point = Integer.parseInt(atts.getValue("point"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }

        int socket = -1;
        try
        {
            socket = Integer.parseInt(atts.getValue("socket"));
        }catch(NumberFormatException nfe)
        {
            socket = -1;
        }

        PlugNetworkShape plug = new PlugNetworkShape(panel, currentPatchcord, point, id);
        plug.moveInto(x, y);
        
        switch(point)
        {
            case 1: 
                currentPatchcord.setPlug1(plug);
                break;
            case 2:
                currentPatchcord.setPlug2(plug);
                break;
            default: throw new SAXException("Error point value: "+point);
        }

        if(socket >= 0)
        {
            SocketNetworkShape connectedSocket = panel.getSocketById(socket);            
            plug.setConnectedSocket(connectedSocket);
        }
    }    
        
    
    

    
    
    
    
    
    private void loadPort(Attributes atts) throws SAXException {
      int id = -1;
      try {
        id = Integer.parseInt(atts.getValue("id"));
      } catch(NumberFormatException nfe) {
        throw new SAXException(nfe);
      }
        
      Port port = new Port(panel.getIdGenerator(), id);
      currentConcentrator.addPort(port);
    }    
    
    
    
    
    
    
    
    
    
    private void loadRoutingTableRow(Attributes atts)
    throws SAXException
    {
        IP4Address target = null;
        try
        {
            target = new IP4Address(atts.getValue("target"));
        }catch(AddressException ae)
        {
            throw new SAXException(ae);
        }

        IP4Address netmask = null;
        try
        {
            netmask = new IP4Address(atts.getValue("netmask"));
        }catch(AddressException ae)
        {
            throw new SAXException(ae);
        }
        
        int metric = -1;
        try
        {
            metric = Integer.parseInt(atts.getValue("metric"));
        }catch(NumberFormatException nfe)
        {
            throw new SAXException(nfe);
        }
        
        String attr = atts.getValue("gateway");
        IP4Address gateway = null;
        if(attr!=null && attr.length()!=0)
        {
            try
            {
                gateway = new IP4Address(attr);
            }catch(AddressException ae)
            {
                throw new SAXException(ae);
            }
        }

        Interface iface = 
                currentRouter.getInterface(atts.getValue("iface"));
        
        try
        {
            currentRoutingTable.addRoute(target, netmask, gateway, metric, iface);
        }catch(Exception e)
        {
            throw new SAXException(e);
        }
    }    

    
    
  @Override
    public void run()
    {
        try
        {
            reader.parse(inputSource);         
        }catch(IOException ioe)
        {
            ioe.printStackTrace();
        }catch(SAXException saxe)
        {
            saxe.printStackTrace();
        }finally
        {
            for(Iterator<ProjectXMLLoadingCompleteListener> i=loadingListeners.iterator(); i.hasNext(); )
            {
                ProjectXMLLoadingCompleteListener l = i.next();
                l.ProjectLoadingComplete();
                i.remove();
            }            
        }
    }
    
    
    
    public void addProjectXMLLoadingCompleteListener(ProjectXMLLoadingCompleteListener listener)
    {
        loadingListeners.add(listener);
    }
    
    
    public void removeProjectXMLLoadingCompleteListener(ProjectXMLLoadingCompleteListener listener)
    {
        loadingListeners.remove(listener);
    }
     
}
