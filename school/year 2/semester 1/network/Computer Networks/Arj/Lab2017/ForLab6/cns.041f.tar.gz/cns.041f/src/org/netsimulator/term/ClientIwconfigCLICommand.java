/*
Computer Network Simulator (CNS)
Copyright (C) 2006 Maxim Tereshin <maxim-tereshin@yandex.ru>
Copyright (C) 2012 Igor A. Nebaev <opds@darkstar.su>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
*/
package org.netsimulator.term;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.logging.Logger;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.MissingArgumentException;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.UnrecognizedOptionException;
import org.netsimulator.net.AddressException;
import org.netsimulator.net.ChangeInterfacePropertyException;
import org.netsimulator.net.EthernetInterface;
import org.netsimulator.net.IP4Address;
import org.netsimulator.net.IP4EnabledInterface;
import org.netsimulator.net.IP4Router;
import org.netsimulator.net.Interface;
import org.netsimulator.net.Router;
import org.netsimulator.net.WifiNetworks;

public class ClientIwconfigCLICommand implements CLICommand {
  private Terminal term;
  private Writer writer;
  private Router router;
  private WifiNetworks wifi;
  private static final Options options = new Options();

  private final static Logger LOG =
          Logger.getLogger(ClientIwconfigCLICommand.class.getName());

  private static final String ENABLE_OPTION = "enable";
  private static final String DISABLE_OPTION = "disable";
  private static final String PASSWORD_OPTION = "p";
  private static final String SSID_OPTION = "essid";
  private static final String HELP_OPTION = "h";
  private static final String IP_ADDRESS = "address";
  private static final String BROADCAST = "broadcast";
  private static final String NETMASK = "netmask";

  /**
   * Constructor for Wi-Fi client (Laptop).
   * @param term console
   * @param router Wi-Fi client
   */
  public ClientIwconfigCLICommand(Terminal term, Router router) {
    this.term = term;
    this.router = router;

    wifi = WifiNetworks.getInstance();

    Option help = new Option(HELP_OPTION, false, "вывести справку");
    options.addOption(help);
    Option statusUp = new Option(ENABLE_OPTION, false,
            "активировать Wi-Fi интерфейс");
    Option statusDown = new Option(DISABLE_OPTION, false,
            "отключить Wi-Fi интерфейс");

    options.addOption(statusUp);
    options.addOption(statusDown);

    Option password = OptionBuilder.withArgName("password")
            .hasArg()
            .withDescription("пароль для подключения к Wi-Fi сети")
            .create(PASSWORD_OPTION);
    options.addOption(password);

    Option ssid = OptionBuilder.withArgName("ESSID")
            .hasArg()
            .withDescription("ID Wi-Fi сети")
            .create(SSID_OPTION);
    options.addOption(ssid);

    Option address = OptionBuilder.withArgName("address")
            .hasArg()
            .withDescription("IP адрес")
            .create(IP_ADDRESS);
    options.addOption(address);

    Option broadcast = OptionBuilder.withArgName("address")
            .hasArg()
            .withDescription("Широковещательный адрес")
            .create(BROADCAST);
    options.addOption(broadcast);

    Option netmask = OptionBuilder.withArgName("address")
            .hasArg()
            .withDescription("Маска подсети")
            .create(NETMASK);
    options.addOption(netmask);
  }

  @Override
  public String getName() {
    return "iwconfig";
  }

  @Override
  public int Go(String argv[], String cl) throws IOException {
    CommandLineParser parser = new GnuParser();
    CommandLine cmd = null;
    try {
      cmd = parser.parse(options, argv);
    } catch (MissingArgumentException e) {
      writer.write("Недостаточно аргументов\n");
      return -1;
    } catch(UnrecognizedOptionException e) {
      writer.write("Недопустимые аргументы\n");
      return -1;
    } catch(ParseException e) {
      e.printStackTrace();
      return -1;
    }

    String args[] = cmd.getArgs();

    if(cmd.hasOption(HELP_OPTION) || (args.length < 1)) {
      showHelp();
      return 0;
    }

    // unknown arguments
    if(args.length > 1) {
      showHelp();
      return 0;
    }

    String essid = null;
    String password = "";
    Interface curInterface = null;
    int updown = Interface.UNKNOWN;
    IP4Address address = null;
    IP4Address netmask = null;
    IP4Address broadcast = null;

    try {
      broadcast = new IP4Address("255.255.255.255");
    } catch (AddressException e) {
      LOG.severe(hashCode()+": wrong default broadcast address!");
    }

    // only for laptop
    if(!args[0].equals(IP4Router.WLAN_IF_NAME)) {
      writer.write("Заданный интерфейс не существует\n");
      return -1;
    }

    curInterface=router.getInterface(args[0]);
    if(curInterface == null) {
      writer.write("Недопустимый интерфейс\n");
      return -1;
    }

    EthernetInterface curEthInterface = null;
    if(curInterface instanceof EthernetInterface) {
      curEthInterface =
              (EthernetInterface) router.getInterface(IP4Router.WLAN_IF_NAME);
    } else {
      writer.write("Системная ошибка\n");
      return -1;
    }
    updown = curEthInterface.getStatus();
    
    // if no arguments  show current status
    if(args.length == 1
            && !cmd.hasOption(ENABLE_OPTION)
            && !cmd.hasOption(DISABLE_OPTION)
            && !cmd.hasOption(SSID_OPTION)
            && !cmd.hasOption(PASSWORD_OPTION)
            && !cmd.hasOption(IP_ADDRESS)
            && !cmd.hasOption(BROADCAST)
            && !cmd.hasOption(NETMASK)) {
      showStatus();
      return 0;
    }

    if(cmd.hasOption(IP_ADDRESS)) {
      try {
        address = new IP4Address(cmd.getOptionValue(IP_ADDRESS));
      } catch(AddressException e) {
        e.printStackTrace();
        writer.write("Недопустимый IP-адрес\n");
        return -1;
      }
    }

    if(cmd.hasOption(BROADCAST)) {
      try {
        broadcast = new IP4Address(cmd.getOptionValue(BROADCAST));
      } catch(AddressException e) {
        e.printStackTrace();
        writer.write("Недопустимый широковещательный адрес\n");
        return -1;
      }
    }

    if(cmd.hasOption(NETMASK)) {
      try {
        netmask = new IP4Address(cmd.getOptionValue(NETMASK));
      } catch(AddressException e) {
        e.printStackTrace();
        writer.write("Недопустимая маска подсети\n");
        return -1;
      }
    }

    if(cmd.hasOption(SSID_OPTION)) {
      essid = cmd.getOptionValue(SSID_OPTION);
      if (essid.trim().length() < 3) {
        writer.write("Недопустимый ESSID\n");
        return -1;
      }
    }

    if(cmd.hasOption(PASSWORD_OPTION)) {
      // If you change password, all current Wi-Fi connections will be
      // destroyed!
      password = cmd.getOptionValue(PASSWORD_OPTION);
      if (password.trim().length() < 3) {
        writer.write("Недопустимый пароль\n");
        return -1;
      }
    }

    if(cmd.hasOption(ENABLE_OPTION) && cmd.hasOption(DISABLE_OPTION)) {
      writer.write("Опции '-enable' и '-disable' взаимоисключаемы\n");
      return -1;
    }

    if(cmd.hasOption(ENABLE_OPTION)) {
      updown = Interface.UP;
    }

    if(cmd.hasOption(DISABLE_OPTION)) {
      updown = Interface.DOWN;
    }

    // try to execute command
    String s = null;
    if (router.hasWifiChannel()) {
      s = router.getWifiChannel().getSsid();
    }
    if ((essid == null)
            && (s == null)
            && (updown == Interface.UP)) {
      // can't activate interface without ssid
      updown = Interface.DOWN;
      writer.write("Не указан ESSID\n");
      return -1;
    }

    if ((((address == null && curEthInterface.getInetAddress() == null)
            || (netmask == null && curEthInterface.getNetmaskAddress() == null))
            && updown == Interface.UP)) {
      // can't activate interface without address and netmask
      updown = Interface.DOWN;
      writer.write("Не указаны IP адрес или маска подсети\n");
      return -1;
    }

    try {
      // stop interface and destroy wi-fi connection
      boolean up = false;
      if(updown == Interface.UP) {
        // save status
        up = true;
      }
      
      curInterface.setStatus(Interface.DOWN);

      if (router.hasWifiChannel()) {
        if (essid == null) {
          essid = router.getWifiChannel().getSsid();
        }

        if (password.equals("")) {
          password = router.getWifiChannel().getPassword();
        }

        if (up) {
          router.destroyWifiChannel();
        }
      }

      IP4EnabledInterface iface = null;
      if(curInterface instanceof IP4EnabledInterface) {
        iface = (IP4EnabledInterface)curInterface;
      } else {
        writer.write(curInterface+" не поддерживает IPv4\n");
        return -1;
      }

      if(address != null) {
        iface.setInetAddress(address);
      }

      if(netmask != null) {
        iface.setNetmaskAddress(netmask);
      }

      if(broadcast != null) {
        iface.setBroadcastAddress(broadcast);
      }

      if(essid != null) {
        router.setWifiChannel(essid, password);
      }

      if(up) {
        int result = router.getWifiChannel().createChannel();
        if(result == 1) {
          writer.write("Wi-Fi Access Point перегружен\n");
          return -1;
        }

        if(result == 2) {
          writer.write("Wi-Fi Access Point с заданным ESSID не обнаружен\n");
          return -1;
        }

        if(result == 3) {
          writer.write("Ошибка сети\n");
          return -1;
        }

        if(result == 4) {
          writer.write("Ошибка аутентификации\n");
          return -1;
        }

        curInterface.setStatus(Interface.UP);
      }

    } catch (ChangeInterfacePropertyException e) {
      writer.write(e.getMessage()+"\n");
      return -1;
    }

    return 0;
  }

  private void showStatus() throws IOException {
    writer.write("Интерфейс: wlan0\nIEEE 802.11b\n");

    if (!router.hasWifiChannel()) {
      writer.write("Wi-Fi статус: не активен\n");
    } else {
      String ssid = router.getWifiChannel().getSsid();
      writer.write("ESSID: " + ssid);
      String password = router.getWifiChannel().getPassword();
      if (password.equals("")) {
        writer.write("\nWi-Fi аутентификация: нет\n");
      } else {
        writer.write("\nПароль: " + password + "\n");
      }
    }

    EthernetInterface ifs = null;
    if(router.getInterface(IP4Router.WLAN_IF_NAME)
            instanceof EthernetInterface) {
      ifs = (EthernetInterface) router.getInterface(IP4Router.WLAN_IF_NAME);
    } else {
      return;
    }

    if (ifs.getStatus() == Interface.DOWN) {
      writer.write("Статус: не активен\n");
      return;
    }

    writer.write("Статус: активен\n");

    if(ifs.getInetAddress() != null) {
      writer.write("inet addr: " + ifs.getInetAddress());
      writer.write("  Bcast: " + ifs.getBroadcastAddress());
      writer.write("  Mask: " + ifs.getNetmaskAddress() + "\n");
    }

    writer.write("RX packets: " + ifs.getRXPackets());
    writer.write("  errors: " + ifs.getRXPacketsErrors());
    writer.write("  dropped: " + ifs.getRXDroped() + "\n");
            
    writer.write("TX packets: " + ifs.getTXPackets());
    writer.write("  errors: " + ifs.getTXPacketsErrors());
    writer.write("  dropped: " + ifs.getTXDroped() + "\n");

    writer.write("RX bytes: " + ifs.getRXBytes());
    writer.write("TX bytes: " + ifs.getTXBytes() + "\n");
  }

  private void showHelp() {
    HelpFormatter formatter = new HelpFormatter();
    formatter.printHelp(new PrintWriter(writer),
            80,
            "iwconfig [-h] [<интерфейс>] [-essid <essid>] [-p <password>] "
            + "[-address <IP-адрес>] [-broadcast <широковещательный IP-адрес>] "
            + "[-netmask <Маска подсети>][-enable|disable]",
            "Настройка Wi-Fi интерфейса wlan0. При указании интерфейса без "
            + "аргументов iwconfig выводит текущий статус Wi-Fi интерфейса.",
            options,
            3,
            2,
            null,
            false);
  }

  @Override
  public void setOutputWriter(Writer writer) {
    this.writer = writer;
  }

  @Override
  public void Stop() {
    // ignoring
  }
}
